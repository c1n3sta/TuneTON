import MusicApp from "./components/MusicApp";

export default function App() {
  return <MusicApp />;
}