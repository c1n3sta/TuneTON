import { useState } from "react";
import { Play, Pause, Search, Plus, Filter, ChevronRight } from "lucide-react";
import svgPaths from "../imports/svg-karfaoua2a";

// Import all the images from the Figma design
import imgAlbumArt from "figma:asset/b13483f5f235f1c26e9cbdbfb40edb8ca3b9c11c.png";
import imgPlaylistCover from "figma:asset/e4df5775c88dbb71f1c09a72f65ba80adc015b71.png";
import imgPlaylistCover1 from "figma:asset/059d630bf1b73c65663230f6fe3660d07bc060b8.png";
import imgPlaylistCover2 from "figma:asset/20bb8fe31b212ec3236e8224dd3efe441043be2f.png";
import imgPlaylistCover3 from "figma:asset/a1ad22f09bf6f15ef5bc637a1785d31b1ca3884a.png";
import imgPlaylistCover4 from "figma:asset/08ea158ebabf976cca7bb1f8ec91d0c456a2f915.png";
import imgTrackCover from "figma:asset/5c0570c22db9da4233071e8dc020249fbd9aeece.png";
import imgTrackCover1 from "figma:asset/ee4dceec67617340be718a9b700bd99946447425.png";
import imgFeaturedRemixCover from "figma:asset/92af5e42f7a6be5cc4a3570d7557d9b846376457.png";
import imgRemixCover from "figma:asset/b4d5d93e0e03aef0e9252522600b2fe91d9305c2.png";
import imgRemixerAvatar from "figma:asset/02641910bdc93d1d98cf6da313c9fe42f75a5679.png";
import imgRemixCover1 from "figma:asset/2445cdb838670e8ea661ef232b16e90503fdec0b.png";
import imgRemixerAvatar1 from "figma:asset/66f8b9f85ad861c00f8936ae6466a1d89cdac769.png";
import imgRemixCover2 from "figma:asset/f6899fe4451eb26d22ac13df75a794b76f152b36.png";
import imgRemixerAvatar2 from "figma:asset/942f88b3ac884230b9cb4196019616c8ea6fb6a0.png";

export default function MusicApp() {
  const [currentTrack, setCurrentTrack] = useState("Starlight Serenade");
  const [isPlaying, setIsPlaying] = useState(true);
  const [selectedFilter, setSelectedFilter] = useState("Most Liked");
  const [activeTab, setActiveTab] = useState("Player");
  const [searchQuery, setSearchQuery] = useState("");
  const [likedTracks, setLikedTracks] = useState(new Set());

  const togglePlay = () => setIsPlaying(!isPlaying);
  
  const toggleLike = (trackId: string) => {
    const newLiked = new Set(likedTracks);
    if (newLiked.has(trackId)) {
      newLiked.delete(trackId);
    } else {
      newLiked.add(trackId);
    }
    setLikedTracks(newLiked);
  };

  const playTrack = (trackName: string) => {
    setCurrentTrack(trackName);
    setIsPlaying(true);
  };

  return (
    <div className="bg-[#0d1117] min-h-screen text-white">
      <div className="flex justify-center">
        <div className="w-[400px] bg-[#161b22] rounded-2xl p-6 pb-0 min-h-screen">
          {/* Header with Search */}
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-[18px] font-semibold text-[#c9d1d9] font-['Montserrat']">Recently Played</h2>
            <button className="w-5 h-5 text-[#8b949e] hover:text-[#ff22fb] transition-colors">
              <Search className="w-full h-full" />
            </button>
          </div>

          {/* Currently Playing Track */}
          <div className="bg-[#093067] rounded-lg p-4 mb-6">
            <div className="flex items-center gap-4">
              <div 
                className="w-12 h-12 rounded-lg bg-cover bg-center"
                style={{ backgroundImage: `url('${imgAlbumArt}')` }}
              />
              <div className="flex-1">
                <h3 className="text-[14px] font-semibold text-[#c9d1d9] font-['Montserrat']">{currentTrack}</h3>
                <p className="text-[12px] text-[#8b949e] font-['Montserrat']">MelodyMix Artist</p>
              </div>
              <div className="flex items-center gap-3">
                {/* Audio Visualizer */}
                <div className="bg-[#484f58] rounded w-10 h-[30px] flex items-end justify-center gap-[3.4px] px-[5.7px]">
                  {[12, 21, 16.5, 25.5, 18].map((height, i) => (
                    <div
                      key={i}
                      className="bg-[#ff22fb] opacity-80 rounded-sm w-[3px] animate-pulse"
                      style={{ 
                        height: `${height}px`,
                        animationDelay: `${i * 0.1}s`,
                        animationDuration: '0.8s'
                      }}
                    />
                  ))}
                </div>
                <button
                  onClick={togglePlay}
                  className="w-6 h-6 text-[#ff22fb] hover:text-[#ff22fb]/80 transition-colors"
                >
                  {isPlaying ? <Pause className="w-full h-full" /> : <Play className="w-full h-full" />}
                </button>
              </div>
            </div>
          </div>

          {/* My Library */}
          <div className="mb-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-[16px] font-semibold text-[#c9d1d9] font-['Montserrat']">My Library</h2>
              <button className="w-5 h-5 text-[#ff22fb] hover:text-[#ff22fb]/80 transition-colors">
                <Plus className="w-full h-full" />
              </button>
            </div>
            <div className="flex gap-4">
              {[
                { cover: imgPlaylistCover, name: "Chill Vibes", tracks: "15 tracks" },
                { cover: imgPlaylistCover1, name: "Workout Mix", tracks: "22 tracks" },
                { cover: imgPlaylistCover2, name: "Focus Beats", tracks: "10 tracks" }
              ].map((playlist, i) => (
                <button
                  key={i}
                  onClick={() => playTrack(playlist.name)}
                  className="bg-[#161b22] rounded-lg p-2 hover:bg-[#21262d] transition-colors"
                >
                  <div 
                    className="w-[90.66px] h-[100px] rounded-lg bg-cover bg-center mb-2"
                    style={{ backgroundImage: `url('${playlist.cover}')` }}
                  />
                  <h3 className="text-[14px] font-semibold text-[#c9d1d9] text-center font-['Montserrat']">{playlist.name}</h3>
                  <p className="text-[12px] text-[#8b949e] text-center font-['Montserrat']">{playlist.tracks}</p>
                </button>
              ))}
            </div>
          </div>

          {/* Community Playlists */}
          <div className="mb-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-[16px] font-semibold text-[#c9d1d9] font-['Montserrat']">Community Playlists</h2>
              <button className="flex items-center gap-1 text-[#ff22fb] hover:text-[#ff22fb]/80 transition-colors">
                <Plus className="w-5 h-5" />
                <span className="text-[14px] font-semibold font-['Montserrat']">Create</span>
              </button>
            </div>
            <div className="flex gap-4">
              {[
                { cover: imgPlaylistCover3, name: "Collab Jams", tracks: "8 tracks" },
                { cover: imgPlaylistCover4, name: "Project Alpha", tracks: "12 tracks" }
              ].map((playlist, i) => (
                <button
                  key={i}
                  onClick={() => playTrack(playlist.name)}
                  className="bg-[#161b22] rounded-lg p-2 hover:bg-[#21262d] transition-colors"
                >
                  <div 
                    className="w-[90.66px] h-[100px] rounded-lg bg-cover bg-center mb-2"
                    style={{ backgroundImage: `url('${playlist.cover}')` }}
                  />
                  <h3 className="text-[14px] font-semibold text-[#c9d1d9] text-center font-['Montserrat']">{playlist.name}</h3>
                  <p className="text-[12px] text-[#8b949e] text-center font-['Montserrat']">{playlist.tracks}</p>
                </button>
              ))}
            </div>
          </div>

          {/* AI Generated Playlists */}
          <div className="mb-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-[16px] font-semibold text-[#c9d1d9] font-['Montserrat']">AI Generated Playlists</h2>
              <button className="text-[14px] font-semibold text-[#ff22fb] hover:text-[#ff22fb]/80 transition-colors font-['Montserrat']">
                View All
              </button>
            </div>
            <div className="flex gap-4">
              {[
                { cover: imgPlaylistCover4, name: "Morning Fo...", type: "AI Generated" },
                { cover: imgPlaylistCover1, name: "Evening Chill", type: "AI Generated" }
              ].map((playlist, i) => (
                <button
                  key={i}
                  onClick={() => playTrack(playlist.name)}
                  className="bg-[#161b22] rounded-lg p-2 hover:bg-[#21262d] transition-colors"
                >
                  <div 
                    className="w-[90.66px] h-[100px] rounded-lg bg-cover bg-center mb-2"
                    style={{ backgroundImage: `url('${playlist.cover}')` }}
                  />
                  <h3 className="text-[14px] font-semibold text-[#c9d1d9] text-center font-['Montserrat']">{playlist.name}</h3>
                  <p className="text-[12px] text-[#8b949e] text-center font-['Montserrat']">{playlist.type}</p>
                </button>
              ))}
            </div>
          </div>

          {/* Recommended Tracks */}
          <div className="mb-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-[16px] font-semibold text-[#c9d1d9] font-['Montserrat']">Recommended Tracks</h2>
              <button className="text-[14px] font-semibold text-[#ff22fb] hover:text-[#ff22fb]/80 transition-colors font-['Montserrat']">
                View All
              </button>
            </div>
            <div className="space-y-3">
              {[
                { cover: imgTrackCover, name: "Sunset Drive", artist: "Chillwave Collective" },
                { cover: imgTrackCover1, name: "City Lights", artist: "Urban Beats" }
              ].map((track, i) => (
                <div key={i} className="bg-[#161b22] rounded-lg p-3">
                  <div className="flex items-center gap-3">
                    <div 
                      className="w-12 h-12 rounded bg-cover bg-center"
                      style={{ backgroundImage: `url('${track.cover}')` }}
                    />
                    <div className="flex-1">
                      <h3 className="text-[14px] font-semibold text-[#c9d1d9] font-['Montserrat']">{track.name}</h3>
                      <p className="text-[12px] text-[#8b949e] font-['Montserrat']">{track.artist}</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => playTrack(track.name)}
                        className="w-[18px] h-[18px] text-[#8b949e] hover:text-[#ff22fb] transition-colors"
                      >
                        <Play className="w-full h-full" />
                      </button>
                      <button className="w-[18px] h-[18px] text-[#8b949e] hover:text-[#ff22fb] transition-colors">
                        <svg viewBox="0 0 18 18" className="w-full h-full" fill="none">
                          <path
                            d={svgPaths.p3fc8b00}
                            stroke="currentColor"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth="1.5"
                          />
                        </svg>
                      </button>
                      <button className="w-[18px] h-[18px] text-[#8b949e] hover:text-[#ff22fb] transition-colors">
                        <Plus className="w-full h-full" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Challenges/Contest */}
          <div className="mb-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-[16px] font-semibold text-[#c9d1d9] font-['Montserrat']">Challenges \ Contest</h2>
              <button className="text-[14px] font-semibold text-[#ff22fb] hover:text-[#ff22fb]/80 transition-colors font-['Montserrat']">
                View All
              </button>
            </div>
            <div className="space-y-3">
              {[
                { name: "Remix Rumble", timeLeft: "Ends in 3 days", icon: "🏆" },
                { name: "Tempo Master", timeLeft: "New challenge!", icon: "🎵" }
              ].map((challenge, i) => (
                <div key={i} className="bg-[#161b22] rounded-lg p-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-[#ff4400] rounded-[20px] flex items-center justify-center text-[24px]">
                      {challenge.icon}
                    </div>
                    <div className="flex-1">
                      <h3 className="text-[14px] font-semibold text-[#c9d1d9] font-['Montserrat']">{challenge.name}</h3>
                      <p className="text-[12px] text-[#8b949e] font-['Montserrat']">{challenge.timeLeft}</p>
                    </div>
                    <button className="bg-[#ff22fb] px-4 py-2 rounded-[7px] text-[14px] font-semibold text-white hover:bg-[#ff22fb]/90 transition-colors font-['Montserrat']">
                      Join
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Explore Remixes Section */}
          <div className="mb-6">
            <div className="mb-6">
              <h1 className="text-[20px] font-bold text-[#c9d1d9] font-['Inter'] mb-4">
                Explore Remixes & Join the<br />Conversation
              </h1>
              
              {/* Search Bar */}
              <div className="flex items-center gap-2 mb-4">
                <div className="bg-[#161b22] rounded-lg flex items-center gap-2 px-3 py-2 flex-1">
                  <Search className="w-[18px] h-[18px] text-[#8b949e]" />
                  <input
                    type="text"
                    placeholder="Search remixes, artists..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="bg-transparent text-[14px] text-[#8b949e] placeholder-[#8b949e] flex-1 outline-none font-['Inter']"
                  />
                </div>
                <button className="bg-[#161b22] p-2 rounded-[6.67px] text-[#8b949e] hover:text-[#ff22fb] transition-colors">
                  <Filter className="w-[18px] h-[18px]" />
                </button>
              </div>

              {/* Filter Buttons */}
              <div className="flex gap-2 mb-4">
                {["Most Liked", "Most Played", "Trending", "Newest"].map((filter) => (
                  <button
                    key={filter}
                    onClick={() => setSelectedFilter(filter)}
                    className={`px-3 py-2 rounded-md text-[12px] font-bold transition-colors font-['Inter'] ${
                      selectedFilter === filter
                        ? "bg-[#ff22fb] text-white"
                        : "bg-[#161b22] text-[#8b949e] hover:bg-[#21262d]"
                    }`}
                  >
                    {filter}
                  </button>
                ))}
              </div>
            </div>

            {/* Featured Remix Spotlight */}
            <div className="mb-6">
              <h2 className="text-[18px] font-bold text-[#c9d1d9] font-['Inter'] mb-4">Featured Remix Spotlight</h2>
              <div className="relative bg-[#484f58] rounded-2xl h-[200px] overflow-hidden">
                <div 
                  className="absolute inset-0 bg-cover bg-left"
                  style={{ backgroundImage: `url('${imgFeaturedRemixCover}')` }}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#000000cc] to-50% to-[#00000000]" />
                <div className="absolute bottom-0 left-0 right-0 p-4">
                  <h3 className="text-[18px] font-bold text-white font-['Inter'] mb-1">Galactic Groove (Remix)</h3>
                  <p className="text-[12px] text-[rgba(255,255,255,0.7)] font-['Inter'] mb-3">Original by: StarDust • Remixed by: DJ Echo</p>
                  <div className="flex items-center justify-between mb-3">
                    <button
                      onClick={() => playTrack("Galactic Groove (Remix)")}
                      className="bg-[#ff22fb] rounded-full w-12 h-12 flex items-center justify-center text-white hover:bg-[#ff22fb]/90 transition-colors"
                    >
                      <Play className="w-5 h-5" />
                    </button>
                    <div className="flex items-center gap-3 text-[rgba(255,255,255,0.8)]">
                      <div className="flex items-center gap-1">
                        <span className="text-[14px] font-bold font-['Inter']">❤️ 1.2K</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <span className="text-[14px] font-bold font-['Inter']">💬 89</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <span className="text-[14px] font-bold font-['Inter']">🔄 210</span>
                      </div>
                    </div>
                  </div>
                  <button className="bg-[#ff22fb] rounded-[7px] w-full py-2.5 text-[14px] font-bold text-white hover:bg-[#ff22fb]/90 transition-colors font-['Inter'] flex items-center justify-center gap-2">
                    <ChevronRight className="w-4 h-4" />
                    Remix this track
                  </button>
                </div>
              </div>
            </div>

            {/* Community Remixes */}
            <div className="mb-6">
              <h2 className="text-[18px] font-bold text-[#c9d1d9] font-['Inter'] mb-4">Community Remixes</h2>
              <div className="space-y-4">
                {[
                  {
                    id: "remix1",
                    cover: imgRemixCover,
                    title: "Cosmic Drift (Chill Mix)",
                    artist: "BeatMaster",
                    avatar: imgRemixerAvatar,
                    likes: 543,
                    plays: "12.3K",
                    downloads: 87,
                    comments: 32,
                    tags: ["ELECTRONIC", "CHILL"],
                    status: "TRENDING NOW"
                  },
                  {
                    id: "remix2",
                    cover: imgRemixCover1,
                    title: "City Lights (Vaporwave Edit)",
                    artist: "SynthDreamer",
                    avatar: imgRemixerAvatar1,
                    likes: 389,
                    plays: "8.1K",
                    downloads: 65,
                    comments: 20,
                    tags: ["VAPORWAVE", "DREAMY"],
                    status: "NEW RELEASE"
                  },
                  {
                    id: "remix3",
                    cover: imgRemixCover2,
                    title: "Neon Pulse (Club Mix)",
                    artist: "GrooveGuru",
                    avatar: imgRemixerAvatar2,
                    likes: 780,
                    plays: "25.6K",
                    downloads: 112,
                    comments: 45,
                    tags: ["HOUSE", "ENERGETIC"],
                    status: "TOP REMIX"
                  }
                ].map((remix) => (
                  <div key={remix.id} className="bg-[#161b22] border border-[#30363d] rounded-2xl p-[13px]">
                    <div className="flex gap-3">
                      <div 
                        className="w-20 h-20 rounded-lg bg-cover bg-center flex-shrink-0"
                        style={{ backgroundImage: `url('${remix.cover}')` }}
                      />
                      <div className="flex-1 space-y-2">
                        <div>
                          <h3 className="text-[16px] font-bold text-[#c9d1d9] font-['Inter']">{remix.title}</h3>
                          <div className="flex items-center gap-1.5">
                            <div 
                              className="w-5 h-5 rounded-[10px] bg-cover bg-center"
                              style={{ backgroundImage: `url('${remix.avatar}')` }}
                            />
                            <span className="text-[12px] font-bold text-[#8b949e] font-['Inter']">by {remix.artist}</span>
                          </div>
                        </div>
                        
                        <button
                          onClick={() => playTrack(remix.title)}
                          className="bg-[#161b22] rounded-md px-2.5 py-1.5 text-[12px] font-bold text-[#8b949e] hover:text-[#ff22fb] transition-colors font-['Inter'] flex items-center gap-2"
                        >
                          <Play className="w-5 h-5" />
                          Play Preview
                        </button>
                        
                        <div className="flex items-center gap-3 text-[12px] font-bold text-[#8b949e] font-['Inter']">
                          <span>❤️ {remix.likes}</span>
                          <span>📻 {remix.plays}</span>
                          <span>📥 {remix.downloads}</span>
                          <span>💬 {remix.comments}</span>
                        </div>
                        
                        <div className="flex flex-wrap gap-1.5">
                          {remix.tags.map((tag) => (
                            <span key={tag} className="bg-[#161b22] px-2 py-1 rounded-[5px] text-[10px] font-bold text-[#8b949e] uppercase tracking-[0.5px] font-['Inter']">
                              {tag}
                            </span>
                          ))}
                          <span className={`px-2 py-1 rounded-[5px] text-[10px] font-bold text-white uppercase tracking-[0.5px] font-['Inter'] ${
                            remix.status === "TRENDING NOW" ? "bg-[#d29922]" : 
                            remix.status === "NEW RELEASE" ? "bg-[#2ea043]" : "bg-[#ff22fb]"
                          }`}>
                            {remix.status}
                          </span>
                        </div>
                        
                        <div className="flex items-center gap-2 pt-1">
                          <button
                            onClick={() => toggleLike(remix.id)}
                            className={`flex items-center gap-1 text-[12px] font-bold transition-colors font-['Inter'] ${
                              likedTracks.has(remix.id) ? "text-[#ff22fb]" : "text-[#8b949e] hover:text-[#ff22fb]"
                            }`}
                          >
                            <span className="w-4 h-4">❤️</span>
                            Like
                          </button>
                          <button className="flex items-center gap-1 text-[12px] font-bold text-[#8b949e] hover:text-[#ff22fb] transition-colors font-['Inter']">
                            <span className="w-4 h-4">💬</span>
                            Comment
                          </button>
                          <button className="flex items-center gap-1 text-[12px] font-bold text-[#8b949e] hover:text-[#ff22fb] transition-colors font-['Inter']">
                            <span className="w-4 h-4">🔄</span>
                            Share
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Bottom Navigation */}
          <div className="fixed bottom-[17px] left-1/2 transform -translate-x-1/2 bg-[#0d1117] rounded-2xl px-[11.4px] py-3 flex items-center gap-[22.8px]">
            {[
              { name: "Player", icon: "🎵", active: true },
              { name: "Playlist", icon: "📄", active: false },
              { name: "Contests", icon: "🏆", active: false },
              { name: "Profile", icon: "👤", active: false }
            ].map((tab) => (
              <button
                key={tab.name}
                onClick={() => setActiveTab(tab.name)}
                className={`flex flex-col items-center gap-1 px-3 py-2 rounded-lg transition-colors ${
                  activeTab === tab.name 
                    ? "bg-[#58a6ff] text-white" 
                    : "text-[#8b949e] hover:text-[#ff22fb]"
                }`}
              >
                <span className="text-2xl">{tab.icon}</span>
                <span className="text-[12px] font-bold font-['Inter']">{tab.name}</span>
              </button>
            ))}
          </div>
          
          {/* Add bottom padding to prevent content from being hidden behind fixed nav */}
          <div className="h-24" />
        </div>
      </div>
    </div>
  );
}