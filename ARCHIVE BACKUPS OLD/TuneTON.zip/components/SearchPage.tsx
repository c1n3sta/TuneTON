import { useState } from "react";
import { 
  Search, 
  ArrowLeft, 
  Filter, 
  TrendingUp, 
  Clock, 
  Play, 
  Heart, 
  MoreHorizontal,
  Music,
  User,
  Hash,
  Mic,
  Headphones,
  Trophy,
  Folder
} from "lucide-react";
import BottomNavigation from "./BottomNavigation";
import { Button } from "./ui/button";
import { Card, CardContent } from "./ui/card";
import { Input } from "./ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { Badge } from "./ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";

// Import images
import imgTrackCover from "figma:asset/5c0570c22db9da4233071e8dc020249fbd9aeece.png";
import imgTrackCover1 from "figma:asset/ee4dceec67617340be718a9b700bd99946447425.png";
import imgAlbumArt from "figma:asset/b13483f5f235f1c26e9cbdbfb40edb8ca3b9c11c.png";
import imgRemixerAvatar from "figma:asset/02641910bdc93d1d98cf6da313c9fe42f75a5679.png";
import imgRemixerAvatar1 from "figma:asset/66f8b9f85ad861c00f8936ae6466a1d89cdac769.png";
import imgRemixerAvatar2 from "figma:asset/942f88b3ac884230b9cb4196019616c8ea6fb6a0.png";

interface SearchPageProps {
  onBack?: () => void;
  onNavigate?: (tab: string, page?: string) => void;
  onTrackSelect?: (track: string) => void;
}

export default function SearchPage({ onBack, onNavigate, onTrackSelect }: SearchPageProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [activeTab, setActiveTab] = useState("all");

  const trendingSearches = [
    "Lo-Fi Hip Hop",
    "Synthwave",
    "Speed Remixes",
    "AI Generated",
    "Vocal Remove",
    "Bass Boost"
  ];

  const searchResults = {
    tracks: [
      {
        id: "1",
        title: "Starlight Serenade",
        artist: "MelodyMix Artist", 
        cover: imgAlbumArt,
        duration: "3:23",
        plays: "1.2M",
        isLiked: false
      },
      {
        id: "2",
        title: "Sunset Drive",
        artist: "Chillwave Collective",
        cover: imgTrackCover,
        duration: "4:12", 
        plays: "890K",
        isLiked: true
      },
      {
        id: "3",
        title: "City Lights",
        artist: "Urban Beats",
        cover: imgTrackCover1,
        duration: "3:45",
        plays: "654K", 
        isLiked: false
      }
    ],
    artists: [
      {
        id: "1",
        name: "MelodyMix Artist",
        avatar: imgRemixerAvatar,
        followers: "2.1M",
        isVerified: true,
        topTrack: "Starlight Serenade"
      },
      {
        id: "2", 
        name: "Chillwave Collective",
        avatar: imgRemixerAvatar1,
        followers: "1.8M",
        isVerified: true,
        topTrack: "Sunset Drive"
      },
      {
        id: "3",
        name: "Urban Beats", 
        avatar: imgRemixerAvatar2,
        followers: "1.5M",
        isVerified: false,
        topTrack: "City Lights"
      }
    ],
    remixes: [
      {
        id: "1",
        title: "Neon Dreams (Lo-Fi Remix)",
        originalArtist: "Synthwave Pro",
        remixer: "LoFiMaster",
        remixerAvatar: imgRemixerAvatar,
        cover: imgAlbumArt,
        likes: 2847,
        plays: 28600,
        effects: ["Lo-Fi", "Vinyl", "Rain"]
      },
      {
        id: "2",
        title: "Ocean Waves (Speed Mix)", 
        originalArtist: "Nature Sounds",
        remixer: "SpeedMaster",
        remixerAvatar: imgRemixerAvatar1,
        cover: imgTrackCover,
        likes: 1892,
        plays: 19300,
        effects: ["Tempo +25%", "Bass Boost"]
      }
    ]
  };

  const handleSearch = (query: string) => {
    setSearchQuery(query);
    // In real app, this would trigger search API
  };

  const handlePlayTrack = (track: string) => {
    if (onTrackSelect) {
      onTrackSelect(track);
    }
    if (onNavigate) {
      onNavigate("Player", "player");
    }
  };

  return (
    <div className="bg-background min-h-screen text-foreground">
      <div className="flex justify-center">
        <div className="w-full max-w-md bg-card rounded-2xl min-h-screen relative overflow-hidden border border-border">
          
          {/* Header */}
          <div className="sticky top-0 z-50 bg-card/80 backdrop-blur-sm border-b border-border">
            <div className="flex items-center gap-4 p-6 pb-4">
              <Button 
                variant="ghost" 
                size="sm" 
                className="w-10 h-10 p-0 rounded-full"
                onClick={onBack}
              >
                <ArrowLeft className="w-5 h-5" />
              </Button>
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  placeholder="Search tracks, artists, remixes..."
                  value={searchQuery}
                  onChange={(e) => handleSearch(e.target.value)}
                  className="pl-10 pr-12 bg-muted border-0"
                />
                {searchQuery && (
                  <Button
                    variant="ghost"
                    size="sm"
                    className="absolute right-1 top-1/2 transform -translate-y-1/2 w-8 h-8 p-0"
                    onClick={() => setSearchQuery("")}
                  >
                    ×
                  </Button>
                )}
              </div>
              <Button variant="ghost" size="sm" className="w-10 h-10 p-0">
                <Filter className="w-5 h-5" />
              </Button>
            </div>
          </div>

          {/* Main Content */}
          <div className="px-6 pb-32">
            
            {!searchQuery && (
              <>
                {/* Trending Searches */}
                <div className="space-y-4 mb-8">
                  <div className="flex items-center gap-2">
                    <TrendingUp className="w-5 h-5 text-chart-1" />
                    <h2 className="font-medium">Trending Now</h2>
                  </div>
                  
                  <div className="flex flex-wrap gap-2">
                    {trendingSearches.map((term, index) => (
                      <Button
                        key={index}
                        variant="outline"
                        size="sm"
                        className="rounded-full h-8"
                        onClick={() => handleSearch(term)}
                      >
                        <Hash className="w-3 h-3 mr-1" />
                        {term}
                      </Button>
                    ))}
                  </div>
                </div>

                {/* Recent Searches */}
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Clock className="w-5 h-5 text-muted-foreground" />
                      <h2 className="font-medium">Recent</h2>
                    </div>
                    <Button variant="ghost" size="sm" className="text-muted-foreground">
                      Clear all
                    </Button>
                  </div>
                  
                  <div className="space-y-2">
                    {["Lo-Fi Beats", "Synthwave Mix", "AI Studio"].map((term, index) => (
                      <Card 
                        key={index}
                        className="cursor-pointer hover:bg-accent transition-colors"
                        onClick={() => handleSearch(term)}
                      >
                        <CardContent className="p-3">
                          <div className="flex items-center gap-3">
                            <Clock className="w-4 h-4 text-muted-foreground" />
                            <span className="text-sm">{term}</span>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </div>
              </>
            )}

            {searchQuery && (
              <div className="space-y-6">
                {/* Search Results Tabs */}
                <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
                  <TabsList className="grid w-full grid-cols-4">
                    <TabsTrigger value="all" className="text-xs">All</TabsTrigger>
                    <TabsTrigger value="tracks" className="text-xs">Tracks</TabsTrigger>
                    <TabsTrigger value="artists" className="text-xs">Artists</TabsTrigger>
                    <TabsTrigger value="remixes" className="text-xs">Remixes</TabsTrigger>
                  </TabsList>

                  <TabsContent value="all" className="space-y-6 mt-6">
                    {/* Quick Results */}
                    <div className="space-y-4">
                      <h3 className="font-medium flex items-center gap-2">
                        <Music className="w-4 h-4" />
                        Top Result
                      </h3>
                      <Card 
                        className="cursor-pointer hover:bg-accent transition-colors"
                        onClick={() => handlePlayTrack(searchResults.tracks[0].title)}
                      >
                        <CardContent className="p-4">
                          <div className="flex items-center gap-4">
                            <div 
                              className="w-16 h-16 rounded-xl bg-cover bg-center border border-border"
                              style={{ backgroundImage: `url('${searchResults.tracks[0].cover}')` }}
                            />
                            <div className="flex-1">
                              <h4 className="font-medium">{searchResults.tracks[0].title}</h4>
                              <p className="text-sm text-muted-foreground">{searchResults.tracks[0].artist}</p>
                              <div className="flex items-center gap-2 mt-1">
                                <Badge variant="secondary" className="text-xs">Track</Badge>
                                <span className="text-xs text-muted-foreground">{searchResults.tracks[0].plays} plays</span>
                              </div>
                            </div>
                            <Button variant="ghost" size="sm" className="w-10 h-10 p-0">
                              <Play className="w-5 h-5" />
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    </div>

                    {/* Artists */}
                    <div className="space-y-4">
                      <h3 className="font-medium flex items-center gap-2">
                        <User className="w-4 h-4" />
                        Artists
                      </h3>
                      <div className="flex gap-4 overflow-x-auto pb-2">
                        {searchResults.artists.slice(0, 3).map((artist) => (
                          <Card 
                            key={artist.id}
                            className="flex-shrink-0 w-32 cursor-pointer hover:bg-accent transition-colors"
                            onClick={() => onNavigate?.("Home", "artist-page")}
                          >
                            <CardContent className="p-3 text-center">
                              <Avatar className="w-16 h-16 mx-auto mb-2">
                                <AvatarImage src={artist.avatar} />
                                <AvatarFallback>{artist.name.charAt(0)}</AvatarFallback>
                              </Avatar>
                              <h4 className="font-medium text-sm truncate">{artist.name}</h4>
                              <p className="text-xs text-muted-foreground">{artist.followers}</p>
                            </CardContent>
                          </Card>
                        ))}
                      </div>
                    </div>

                    {/* Tracks */}
                    <div className="space-y-4">
                      <h3 className="font-medium flex items-center gap-2">
                        <Headphones className="w-4 h-4" />
                        Tracks
                      </h3>
                      <div className="space-y-2">
                        {searchResults.tracks.slice(1, 3).map((track) => (
                          <Card 
                            key={track.id}
                            className="cursor-pointer hover:bg-accent transition-colors"
                            onClick={() => handlePlayTrack(track.title)}
                          >
                            <CardContent className="p-3">
                              <div className="flex items-center gap-3">
                                <div 
                                  className="w-12 h-12 rounded-lg bg-cover bg-center border border-border"
                                  style={{ backgroundImage: `url('${track.cover}')` }}
                                />
                                <div className="flex-1 min-w-0">
                                  <h4 className="font-medium text-sm truncate">{track.title}</h4>
                                  <p className="text-xs text-muted-foreground truncate">{track.artist}</p>
                                </div>
                                <div className="flex items-center gap-2">
                                  <span className="text-xs text-muted-foreground">{track.duration}</span>
                                  <Button 
                                    variant="ghost" 
                                    size="sm" 
                                    className={`w-6 h-6 p-0 ${track.isLiked ? 'text-destructive' : 'text-muted-foreground'}`}
                                  >
                                    <Heart className={`w-4 h-4 ${track.isLiked ? 'fill-current' : ''}`} />
                                  </Button>
                                  <Button variant="ghost" size="sm" className="w-6 h-6 p-0">
                                    <MoreHorizontal className="w-4 h-4" />
                                  </Button>
                                </div>
                              </div>
                            </CardContent>
                          </Card>
                        ))}
                      </div>
                    </div>
                  </TabsContent>

                  <TabsContent value="tracks" className="space-y-4 mt-6">
                    {searchResults.tracks.map((track) => (
                      <Card 
                        key={track.id}
                        className="cursor-pointer hover:bg-accent transition-colors"
                        onClick={() => handlePlayTrack(track.title)}
                      >
                        <CardContent className="p-4">
                          <div className="flex items-center gap-3">
                            <div 
                              className="w-14 h-14 rounded-lg bg-cover bg-center border border-border"
                              style={{ backgroundImage: `url('${track.cover}')` }}
                            />
                            <div className="flex-1 min-w-0">
                              <h4 className="font-medium truncate">{track.title}</h4>
                              <p className="text-sm text-muted-foreground truncate">{track.artist}</p>
                              <div className="flex items-center gap-2 mt-1">
                                <span className="text-xs text-muted-foreground">{track.plays} plays</span>
                                <span className="text-xs text-muted-foreground">•</span>
                                <span className="text-xs text-muted-foreground">{track.duration}</span>
                              </div>
                            </div>
                            <div className="flex items-center gap-2">
                              <Button 
                                variant="ghost" 
                                size="sm" 
                                className={`w-8 h-8 p-0 ${track.isLiked ? 'text-destructive' : 'text-muted-foreground'}`}
                              >
                                <Heart className={`w-4 h-4 ${track.isLiked ? 'fill-current' : ''}`} />
                              </Button>
                              <Button variant="ghost" size="sm" className="w-8 h-8 p-0">
                                <MoreHorizontal className="w-4 h-4" />
                              </Button>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </TabsContent>

                  <TabsContent value="artists" className="space-y-4 mt-6">
                    {searchResults.artists.map((artist) => (
                      <Card 
                        key={artist.id}
                        className="cursor-pointer hover:bg-accent transition-colors"
                        onClick={() => onNavigate?.("Home", "artist-page")}
                      >
                        <CardContent className="p-4">
                          <div className="flex items-center gap-3">
                            <Avatar className="w-12 h-12">
                              <AvatarImage src={artist.avatar} />
                              <AvatarFallback>{artist.name.charAt(0)}</AvatarFallback>
                            </Avatar>
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center gap-2">
                                <h4 className="font-medium truncate">{artist.name}</h4>
                                {artist.isVerified && (
                                  <Badge variant="secondary" className="h-4 px-1">
                                    ✓
                                  </Badge>
                                )}
                              </div>
                              <p className="text-sm text-muted-foreground">{artist.followers} followers</p>
                              <p className="text-xs text-muted-foreground">Top: {artist.topTrack}</p>
                            </div>
                            <Button variant="outline" size="sm">
                              Follow
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </TabsContent>

                  <TabsContent value="remixes" className="space-y-4 mt-6">
                    {searchResults.remixes.map((remix) => (
                      <Card 
                        key={remix.id}
                        className="cursor-pointer hover:bg-accent transition-colors"
                        onClick={() => onNavigate?.("Home", "remix-detail")}
                      >
                        <CardContent className="p-4">
                          <div className="flex items-start gap-3">
                            <div 
                              className="w-14 h-14 rounded-lg bg-cover bg-center border border-border"
                              style={{ backgroundImage: `url('${remix.cover}')` }}
                            />
                            <div className="flex-1 min-w-0">
                              <h4 className="font-medium text-sm truncate">{remix.title}</h4>
                              <p className="text-xs text-muted-foreground truncate mb-1">
                                Original by {remix.originalArtist}
                              </p>
                              <div className="flex items-center gap-2 mb-2">
                                <Avatar className="w-4 h-4">
                                  <AvatarImage src={remix.remixerAvatar} />
                                  <AvatarFallback>{remix.remixer.charAt(0)}</AvatarFallback>
                                </Avatar>
                                <span className="text-xs text-muted-foreground">{remix.remixer}</span>
                              </div>
                              <div className="flex items-center gap-1 flex-wrap mb-2">
                                {remix.effects.slice(0, 2).map((effect, index) => (
                                  <Badge key={index} variant="outline" className="text-xs h-4">
                                    {effect}
                                  </Badge>
                                ))}
                              </div>
                              <div className="flex items-center gap-4 text-xs text-muted-foreground">
                                <span className="flex items-center gap-1">
                                  <Heart className="w-3 h-3" />
                                  {remix.likes.toLocaleString()}
                                </span>
                                <span className="flex items-center gap-1">
                                  <Play className="w-3 h-3" />
                                  {remix.plays.toLocaleString()}
                                </span>
                              </div>
                            </div>
                            <Button variant="ghost" size="sm" className="w-6 h-6 p-0">
                              <MoreHorizontal className="w-4 h-4" />
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </TabsContent>
                </Tabs>
              </div>
            )}
          </div>

          {/* Quick Access to Other Features */}
          <div className="px-6 pb-6">
            <div className="flex gap-3 overflow-x-auto">
              <Button 
                variant="outline" 
                size="sm" 
                className="flex-shrink-0 gap-2"
                onClick={() => onNavigate?.("Home", "discover")}
              >
                <TrendingUp className="w-4 h-4" />
                Discover
              </Button>
              <Button 
                variant="outline" 
                size="sm" 
                className="flex-shrink-0 gap-2"
                onClick={() => onNavigate?.("Library")}
              >
                <Folder className="w-4 h-4" />
                Library
              </Button>
              <Button 
                variant="outline" 
                size="sm" 
                className="flex-shrink-0 gap-2"
                onClick={() => onNavigate?.("Home", "ai-studio")}
              >
                <Mic className="w-4 h-4" />
                AI Studio
              </Button>
              <Button 
                variant="outline" 
                size="sm" 
                className="flex-shrink-0 gap-2"
                onClick={() => onNavigate?.("Contests", "contests")}
              >
                <Trophy className="w-4 h-4" />
                Contests
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}